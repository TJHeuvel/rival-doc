using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;
using Rival;
using Unity.Physics;
using Unity.Physics.Authoring;

public struct TutorialCharacterProcessor : IKinematicCharacterProcessor
{
    public float DeltaTime;
    public CollisionWorld CollisionWorld;

    public ComponentDataFromEntity<KinematicCharacterBody> CharacterBodyFromEntity;
    public ComponentDataFromEntity<PhysicsMass> PhysicsMassFromEntity;
    public ComponentDataFromEntity<PhysicsVelocity> PhysicsVelocityFromEntity;
    public ComponentDataFromEntity<TrackedTransform> TrackedTransformFromEntity; 
    public ComponentDataFromEntity<CharacterFrictionSurface> CharacterFrictionSurfaceFromEntity;

    public NativeList<int> TmpRigidbodyIndexesProcessed;
    public NativeList<RaycastHit> TmpRaycastHits;
    public NativeList<ColliderCastHit> TmpColliderCastHits;
    public NativeList<DistanceHit> TmpDistanceHits;

    public Entity Entity;
    public float3 Translation;
    public quaternion Rotation;
    public float3 GroundingUp;
    public PhysicsCollider PhysicsCollider;
    public KinematicCharacterBody CharacterBody;
    public TutorialCharacterComponent TutorialCharacter;
    public TutorialCharacterInputs TutorialCharacterInputs;

    public DynamicBuffer<KinematicCharacterHit> CharacterHitsBuffer;
    public DynamicBuffer<KinematicCharacterDeferredImpulse> CharacterDeferredImpulsesBuffer;
    public DynamicBuffer<KinematicVelocityProjectionHit> VelocityProjectionHitsBuffer;
    public DynamicBuffer<StatefulKinematicCharacterHit> StatefulCharacterHitsBuffer;

    #region Processor Getters
    public CollisionWorld GetCollisionWorld => CollisionWorld;
    public ComponentDataFromEntity<KinematicCharacterBody> GetCharacterBodyFromEntity => CharacterBodyFromEntity;
    public ComponentDataFromEntity<PhysicsMass> GetPhysicsMassFromEntity => PhysicsMassFromEntity;
    public ComponentDataFromEntity<PhysicsVelocity> GetPhysicsVelocityFromEntity => PhysicsVelocityFromEntity;
    public ComponentDataFromEntity<TrackedTransform> GetTrackedTransformFromEntity => TrackedTransformFromEntity;
    public NativeList<int> GetTmpRigidbodyIndexesProcessed => TmpRigidbodyIndexesProcessed;
    public NativeList<RaycastHit> GetTmpRaycastHits => TmpRaycastHits;
    public NativeList<ColliderCastHit> GetTmpColliderCastHits => TmpColliderCastHits;
    public NativeList<DistanceHit> GetTmpDistanceHits => TmpDistanceHits;
    #endregion

    #region Processor Callbacks
    public bool CanCollideWithHit(in BasicHit hit)
    {
        // First, see if we'd have to ignore based on the default implementation
        if (!KinematicCharacterUtilities.DefaultMethods.CanCollideWithHit(in hit, in CharacterBodyFromEntity))
        {
            return false;
        }

        // if not, check for the ignored tag
        if (TutorialCharacter.IgnoredPhysicsTags.Value > CustomPhysicsBodyTags.Nothing.Value)
        {
            if ((CollisionWorld.Bodies[hit.RigidBodyIndex].CustomTags & TutorialCharacter.IgnoredPhysicsTags.Value) > 0)
            {
                return false;
            }
        }

        return true;
    }

    public bool IsGroundedOnHit(in BasicHit hit, int groundingEvaluationType)
    {
        // Prevent grounding from slope change
        if (TutorialCharacter.PreventGroundingWhenMovingTowardsEmptiness || TutorialCharacter.HasMaxDownwardSlopeChangeAngle)
        {
            KinematicCharacterUtilities.DefaultMethods.DetectFutureSlopeChange(
                ref this,
                in hit,
                in CharacterBody,
                in PhysicsCollider,
                Entity,
                GroundingUp,
                0.1f, // verticalOffset
                0.5f, // downDetectionDepth
                0.01f, // deltaTimeIntoFuture
                0.3f, // secondaryEmptinessCheckDistance
                out bool isMovingTowardsEmptiness,
                out bool foundSlopeChange,
                out float futureSlopeChangeAnglesRadians);
            if (TutorialCharacter.PreventGroundingWhenMovingTowardsEmptiness && isMovingTowardsEmptiness)
            {
                return false;
            }
            if (TutorialCharacter.HasMaxDownwardSlopeChangeAngle && foundSlopeChange && math.degrees(futureSlopeChangeAnglesRadians) < -TutorialCharacter.MaxDownwardSlopeChangeAngle)
            {
                return false;
            }
        }

        return KinematicCharacterUtilities.DefaultMethods.IsGroundedOnHit(
            ref this,
            in hit,
            in CharacterBody,
            in PhysicsCollider,
            Entity,
            GroundingUp,
            groundingEvaluationType,
            TutorialCharacter.StepHandling,
            TutorialCharacter.MaxStepHeight,
            TutorialCharacter.ExtraStepChecksDistance);
    }

    public void OnMovementHit(
        ref KinematicCharacterHit hit,
        ref float3 remainingMovementDirection,
        ref float remainingMovementLength,
        float3 originalVelocityDirection,
        float hitDistance)
    {
        KinematicCharacterUtilities.DefaultMethods.OnMovementHit(
            ref this,
            ref hit,
            ref CharacterBody,
            ref VelocityProjectionHitsBuffer,
            ref Translation,
            ref remainingMovementDirection,
            ref remainingMovementLength,
            in PhysicsCollider,
            Entity,
            Rotation,
            GroundingUp,
            originalVelocityDirection,
            hitDistance,
            TutorialCharacter.StepHandling,
            TutorialCharacter.MaxStepHeight);
    }

    public void OverrideDynamicHitMasses(
        ref float characterMass,
        ref float otherMass,
        Entity characterEntity,
        Entity otherEntity,
        int otherRigidbodyIndex,
        bool otherEntityIsCharacter)
    {
    }

    public void ProjectVelocityOnHits(
        ref float3 velocity,
        ref bool characterIsGrounded,
        ref BasicHit characterGroundHit,
        in DynamicBuffer<KinematicVelocityProjectionHit> hits,
        float3 originalVelocityDirection)
    {
        // The last hit in the "hits" buffer is the latest hit. The rest of the hits are all hits so far in the movement iterations
        KinematicCharacterUtilities.DefaultMethods.ProjectVelocityOnHits(
            ref velocity,
            ref characterIsGrounded,
            ref characterGroundHit,
            in hits,
            originalVelocityDirection,
            GroundingUp,
            TutorialCharacter.ConstrainVelocityToGroundPlane);
    }
    #endregion

    public unsafe void OnUpdate()
    {
        GroundingUp = -math.normalizesafe(TutorialCharacter.Gravity);

        KinematicCharacterUtilities.InitializationUpdate(ref CharacterBody, ref CharacterHitsBuffer, ref VelocityProjectionHitsBuffer, ref CharacterDeferredImpulsesBuffer, Rotation);
        KinematicCharacterUtilities.ParentMovementUpdate(ref this, ref Translation, ref Rotation, ref CharacterBody, in PhysicsCollider, DeltaTime, Entity, GroundingUp, CharacterBody.WasGroundedBeforeCharacterUpdate); // safe to remove if not needed
        KinematicCharacterUtilities.GroundingUpdate(ref this, ref Translation, ref CharacterBody, ref CharacterHitsBuffer, ref VelocityProjectionHitsBuffer, in PhysicsCollider, Entity, Rotation, GroundingUp);

			// Character velocity control is updated AFTER the ground has been detected, but BEFORE the character tries to move & collide with that velocity
        HandleCharacterControl();

        if(CharacterBody.IsGrounded && CharacterBody.SimulateDynamicBody)
        {
            KinematicCharacterUtilities.DefaultMethods.UpdateGroundPushing(ref CollisionWorld, ref PhysicsMassFromEntity, ref CharacterDeferredImpulsesBuffer, ref CharacterBody, DeltaTime, TutorialCharacter.Gravity, 1f); // safe to remove if not needed
        }

        KinematicCharacterUtilities.MovementAndDecollisionsUpdate(ref this, ref Translation, ref CharacterBody, ref CharacterHitsBuffer, ref VelocityProjectionHitsBuffer, ref CharacterDeferredImpulsesBuffer, in PhysicsCollider, DeltaTime, Entity, Rotation, GroundingUp);
        KinematicCharacterUtilities.DefaultMethods.MovingPlatformDetection(ref TrackedTransformFromEntity, ref CharacterBodyFromEntity, ref CharacterBody); // safe to remove if not needed
        KinematicCharacterUtilities.ParentMomentumUpdate(ref TrackedTransformFromEntity, ref CharacterBody, in Translation, DeltaTime, GroundingUp); // safe to remove if not needed
        KinematicCharacterUtilities.ProcessStatefulCharacterHits(ref StatefulCharacterHitsBuffer, in CharacterHitsBuffer); // safe to remove if not needed
    }

    public unsafe void HandleCharacterControl()
    {
        if (CharacterBody.IsGrounded)
        {
            // Move on ground
            float3 targetVelocity = TutorialCharacterInputs.WorldMoveVector * TutorialCharacter.GroundMaxSpeed;

            // Handle Sprint
            if (TutorialCharacterInputs.Sprint)
            {
                targetVelocity *= TutorialCharacter.SprintSpeedMultiplier;
            }

            // Modify final velocity based on friction surface
            if (CharacterFrictionSurfaceFromEntity.HasComponent(CharacterBody.GroundHit.Entity))
            {
                targetVelocity *= CharacterFrictionSurfaceFromEntity[CharacterBody.GroundHit.Entity].VelocityFactor;
            }

            CharacterControlUtilities.StandardGroundMove_Interpolated(ref CharacterBody.RelativeVelocity, targetVelocity, TutorialCharacter.GroundedMovementSharpness, DeltaTime, GroundingUp, CharacterBody.GroundHit.Normal);

            // Jump
            if (TutorialCharacterInputs.JumpRequested)
            {
                CharacterControlUtilities.StandardJump(ref CharacterBody, GroundingUp * TutorialCharacter.JumpSpeed, true, GroundingUp);
            }

            // Reset air jumps when grounded
            TutorialCharacter._currentAirJumps = 0;
        }
        else
        {
            // Move in air
            float3 airAcceleration = TutorialCharacterInputs.WorldMoveVector * TutorialCharacter.AirAcceleration;
            CharacterControlUtilities.StandardAirMove(ref CharacterBody.RelativeVelocity, airAcceleration, TutorialCharacter.AirMaxSpeed, GroundingUp, DeltaTime, false);

            // Air Jumps
            if (TutorialCharacterInputs.JumpRequested && TutorialCharacter._currentAirJumps < TutorialCharacter.MaxAirJumps)
            {
                CharacterControlUtilities.StandardJump(ref CharacterBody, GroundingUp * TutorialCharacter.JumpSpeed, true, GroundingUp);
                TutorialCharacter._currentAirJumps++;
            }

            // Gravity
            CharacterControlUtilities.AccelerateVelocity(ref CharacterBody.RelativeVelocity, TutorialCharacter.Gravity, DeltaTime);

            // Drag
            CharacterControlUtilities.ApplyDragToVelocity(ref CharacterBody.RelativeVelocity, DeltaTime, TutorialCharacter.AirDrag);
        }

        // Rotation (towards move direction)
        if (math.lengthsq(TutorialCharacterInputs.WorldMoveVector) > 0f)
        {
            CharacterControlUtilities.SlerpRotationTowardsDirectionAroundUp(ref Rotation, DeltaTime, math.normalizesafe(TutorialCharacterInputs.WorldMoveVector), GroundingUp, TutorialCharacter.RotationSharpness);
        }

        // Reset jump request
        TutorialCharacterInputs.JumpRequested = false;
    }
}
