using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;

// Make the input system update on variable update, and before the FixedStepSimulationSystemGroup (where the character updates)
[UpdateInGroup(typeof(SimulationSystemGroup), OrderFirst = true)]
[UpdateBefore(typeof(FixedStepSimulationSystemGroup))]
public class PlayerSystem : SystemBase
{
    protected override void OnCreate()
    {
        base.OnCreate();

        // Lock the cursor
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    protected override void OnUpdate()
    {
        // Gather raw input
        float2 moveInput = float2.zero;
        moveInput.y += Input.GetKey(KeyCode.W) ? 1f : 0f;
        moveInput.y += Input.GetKey(KeyCode.S) ? -1f : 0f;
        moveInput.x += Input.GetKey(KeyCode.D) ? 1f : 0f;
        moveInput.x += Input.GetKey(KeyCode.A) ? -1f : 0f;
        bool jumpInput = Input.GetKeyDown(KeyCode.Space);
        bool sprintInput = Input.GetKey(KeyCode.LeftShift);
        float2 cameraLookInput = new float2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));
        float cameraZoomInput = -Input.mouseScrollDelta.y;

        // Iterate on all Player components to apply input to their character
        Entities
            .ForEach((ref Player player) =>
            {
                // Calculate camera directions (will be used for character movement directions)
                quaternion cameraRotation = GetComponent<Rotation>(player.ControlledCamera).Value;
                float3 cameraForwardOnUpPlane = math.normalizesafe(Rival.MathUtilities.ProjectOnPlane(Rival.MathUtilities.GetForwardFromRotation(cameraRotation), math.up()));
                float3 cameraRight = Rival.MathUtilities.GetRightFromRotation(cameraRotation);

                // Character control
                if (HasComponent<TutorialCharacterInputs>(player.ControlledCharacter))
                {
                    TutorialCharacterInputs characterInputs = GetComponent<TutorialCharacterInputs>(player.ControlledCharacter);

                    // Make our WorldMoveVector be a vector of magnitude 0 to 1, pointing in the direction of the desired movement (towards camera forward, in this case).
                    // The magnitude of this vector represents the fraction of maximum character speed we wish to have in this direction,
                    // so a magnitude of 1f will correspond to the max velocity, 0.5f will correspond to half of the max velocity, etc...
                    characterInputs.WorldMoveVector = (moveInput.y * cameraForwardOnUpPlane) + (moveInput.x * cameraRight);
                    characterInputs.WorldMoveVector = Rival.MathUtilities.ClampToMaxLength(characterInputs.WorldMoveVector, 1f);

                    // Remember we want to jump, but only if the jump input is true. The character update will handle resetting that value to false every frame.
                    // Since our character updates on a fixed step and our input is gathered at a variable step, this setup is necessary to prevent having your jump
                    // input lost between two fixed updates.
                    if (jumpInput)
                    {
                        characterInputs.JumpRequested = jumpInput;
                    }

                    characterInputs.Sprint = sprintInput;

                    // Don't forget to write back the data to the component
                    SetComponent(player.ControlledCharacter, characterInputs);
                }

                // Camera control
                if (HasComponent<OrbitCameraInputs>(player.ControlledCamera))
                {
                    OrbitCameraInputs cameraInputs = GetComponent<OrbitCameraInputs>(player.ControlledCamera);

                    cameraInputs.Look = cameraLookInput;
                    cameraInputs.Zoom = cameraZoomInput;

                    SetComponent(player.ControlledCamera, cameraInputs);
                }
            }).Schedule();
    }
}