using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;
using Rival;
using Unity.Physics;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Physics.Authoring;

public struct TutorialCharacterProcessor : IKinematicCharacterProcessor
{
    public TutorialCharacterComponent TutorialCharacter;

    public bool CanCollideWithHit(
        ref KinematicCharacterCommonData commonData,
        in BasicHit hit,
        Entity characterEntity)
    {
        // First, see if we'd have to ignore based on the default implementation
        if (!KinematicCharacterUtilities.DefaultMethods.CanCollideWithHit(in hit))
        {
            return false;
        }

        // if not, check for the ignored tag
        if (TutorialCharacter.IgnoredPhysicsTags.Value > CustomPhysicsBodyTags.Nothing.Value)
        {
            if ((commonData.CollisionWorld.Bodies[hit.RigidBodyIndex].CustomTags & TutorialCharacter.IgnoredPhysicsTags.Value) > 0)
            {
                return false;
            }
        }

        return true;
    }

    public void OnMovementHit(
            ref KinematicCharacterCommonData commonData,
            ref KinematicCharacterHit hit,
            ref KinematicCharacterBody characterBody,
            ref float3 characterTranslation,
            ref float3 remainingMovementDirection,
            ref float remainingMovementLength,
            ref DynamicBuffer<KinematicVelocityProjectionHit> velocityProjectionHitsBuffer,
            in PhysicsCollider characterPhysicsCollider,
            Entity characterEntity,
            quaternion characterRotation,
            float3 characterUp,
            float3 originalVelocityDirection,
            float hitDistance)
    {
        KinematicCharacterUtilities.DefaultMethods.OnMovementHit(
            ref commonData,
            ref this,
            ref characterTranslation,
            ref characterBody,
            ref velocityProjectionHitsBuffer,
            ref remainingMovementDirection,
            ref remainingMovementLength,
            characterEntity,
            originalVelocityDirection,
            hitDistance,
            characterUp);
    }

    public bool IsGroundedOnHit(
        ref KinematicCharacterCommonData commonData,
        in BasicHit hit,
        in KinematicCharacterBody characterBody,
        in PhysicsCollider characterPhysicsCollider,
        Entity characterEntity,
        float3 characterTranslation,
        quaternion characterRotation,
        float3 characterUp,
        int groundingEvaluationType)
    {
        return KinematicCharacterUtilities.DefaultMethods.IsGroundedOnHit(
            in hit,
            in characterBody,
            characterUp);
    }

    public void OverrideDynamicHitMasses(
        ref KinematicCharacterCommonData commonData,
        ref float characterMass,
        ref float otherMass,
        Entity characterEntity,
        Entity otherEntity,
        int otherRigidbodyIndex,
        bool otherEntityIsCharacter)
    {
    }

    public void ProjectVelocityOnHits(
        ref KinematicCharacterCommonData commonData,
        ref float3 velocity,
        ref bool characterIsGrounded,
        ref BasicHit characterGroundHit,
        in DynamicBuffer<KinematicVelocityProjectionHit> hits,
        Entity characterEntity,
        float3 originalVelocityDirection,
        float3 characterUp)
    {
        // The last hit in the "hits" buffer is the latest hit. The rest of the hits are all hits so far in the movement iterations
        KinematicCharacterUtilities.DefaultMethods.ProjectVelocityOnHits(
            ref velocity,
            ref characterIsGrounded,
            ref characterGroundHit,
            in hits,
            originalVelocityDirection,
            characterUp);
    }
}