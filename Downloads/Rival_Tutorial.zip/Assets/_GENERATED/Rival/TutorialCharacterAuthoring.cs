using Unity.Entities;
using Unity.Mathematics;
using Unity.Physics.Authoring;
using UnityEngine;
using Rival;
using Unity.Physics;

    [DisallowMultipleComponent]
    [RequireComponent(typeof(PhysicsShapeAuthoring))]
    [UpdateAfter(typeof(EndColliderConversionSystem))]
    public class TutorialCharacterAuthoring : MonoBehaviour, IConvertGameObjectToEntity
    {
        public AuthoringKinematicCharacterBody CharacterBody = AuthoringKinematicCharacterBody.GetDefault();
        public TutorialCharacterComponent TutorialCharacter = TutorialCharacterComponent.GetDefault();

        public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
        {
            KinematicCharacterUtilities.HandleConversionForCharacter(dstManager, entity, gameObject, CharacterBody);

            dstManager.AddComponentData(entity, TutorialCharacter);
            dstManager.AddComponentData(entity, new TutorialCharacterInputs());
        }
    }
