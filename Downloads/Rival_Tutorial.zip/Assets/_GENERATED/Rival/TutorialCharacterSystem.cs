using System.Collections.Generic;
using Unity.Burst;
using Unity.Entities;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Physics;
using Unity.Physics.Extensions;
using Unity.Physics.Systems;
using Unity.Transforms;
using Rival;
using Unity.Collections.LowLevel.Unsafe;

[UpdateInGroup(typeof(KinematicCharacterUpdateGroup))]
public class TutorialCharacterSystem : SystemBase
{
    public BuildPhysicsWorld BuildPhysicsWorldSystem;
    public EndFramePhysicsSystem EndFramePhysicsSystem;
    public EntityQuery CharacterQuery;

    [BurstCompile]
    public struct TutorialCharacterJob : IJobEntityBatchWithIndex
    {
        public float DeltaTime;
        [ReadOnly]
        public CollisionWorld CollisionWorld;

        [ReadOnly]
        public ComponentDataFromEntity<PhysicsVelocity> PhysicsVelocityFromEntity;
        [ReadOnly]
        public ComponentDataFromEntity<PhysicsMass> PhysicsMassFromEntity;
        [NativeDisableParallelForRestriction] // we need to write to our own characterBody, but we might also need to read from other characterBodies during the update (for dynamics handling)
        public ComponentDataFromEntity<KinematicCharacterBody> CharacterBodyFromEntity;
        [ReadOnly]
        public ComponentDataFromEntity<TrackedTransform> TrackedTransformFromEntity;

        [ReadOnly]
        public EntityTypeHandle EntityType;
        public ComponentTypeHandle<Translation> TranslationType;
        public ComponentTypeHandle<Rotation> RotationType;
        public ComponentTypeHandle<PhysicsCollider> PhysicsColliderType;
        public BufferTypeHandle<KinematicCharacterHit> CharacterHitsBufferType;
        public BufferTypeHandle<KinematicVelocityProjectionHit> VelocityProjectionHitsBufferType;
        public BufferTypeHandle<KinematicCharacterDeferredImpulse> CharacterDeferredImpulsesBufferType;
        public BufferTypeHandle<StatefulKinematicCharacterHit> StatefulCharacterHitsBufferType;

        public ComponentTypeHandle<TutorialCharacterComponent> TutorialCharacterType;
        public ComponentTypeHandle<TutorialCharacterInputs> TutorialCharacterInputsType;

        [ReadOnly]
        public ComponentDataFromEntity<CharacterFrictionSurface> CharacterFrictionSurfaceFromEntity;

        [NativeDisableContainerSafetyRestriction]
        private TmpKinematicCharacterCollections _tmpCharacterCollections;

        public void Execute(ArchetypeChunk chunk, int batchIndex, int indexOfFirstEntityInQuery)
        {
            // Prepare character job data
            KinematicCharacterCommonData tmpCommonData = KinematicCharacterCommonData.CreateForThread(DeltaTime, CollisionWorld, CharacterBodyFromEntity, PhysicsMassFromEntity, PhysicsVelocityFromEntity, TrackedTransformFromEntity, _tmpCharacterCollections);

            NativeArray<Entity> chunkEntities = chunk.GetNativeArray(EntityType);
            NativeArray<Translation> chunkTranslations = chunk.GetNativeArray(TranslationType);
            NativeArray<Rotation> chunkRotations = chunk.GetNativeArray(RotationType);
            NativeArray<PhysicsCollider> chunkPhysicsColliders = chunk.GetNativeArray(PhysicsColliderType);
            BufferAccessor<KinematicCharacterHit> chunkCharacterHitBuffers = chunk.GetBufferAccessor(CharacterHitsBufferType);
            BufferAccessor<KinematicVelocityProjectionHit> chunkVelocityProjectionHitBuffers = chunk.GetBufferAccessor(VelocityProjectionHitsBufferType);
            BufferAccessor<KinematicCharacterDeferredImpulse> chunkCharacterDeferredImpulsesBuffers = chunk.GetBufferAccessor(CharacterDeferredImpulsesBufferType);
            BufferAccessor<StatefulKinematicCharacterHit> chunkStatefulCharacterHitsBuffers = chunk.GetBufferAccessor(StatefulCharacterHitsBufferType);
            NativeArray<TutorialCharacterComponent> chunkTutorialCharacters = chunk.GetNativeArray(TutorialCharacterType);
            NativeArray<TutorialCharacterInputs> chunkTutorialCharacterInputs = chunk.GetNativeArray(TutorialCharacterInputsType);

            for (int i = 0; i < chunk.Count; i++)
            {
                Entity entity = chunkEntities[i];

                // Build a data structure containing all that we might need during our update
                TutorialCharacterUpdateData d = new TutorialCharacterUpdateData
                {
                    Processor = new TutorialCharacterProcessor
                    {
                        TutorialCharacter = chunkTutorialCharacters[i],
                    },
                    CommonData = tmpCommonData,

                    Entity = entity,
                    Translation = chunkTranslations[i].Value,
                    Rotation = chunkRotations[i].Value,
                    PhysicsCollider = chunkPhysicsColliders[i],
                    CharacterBody = CharacterBodyFromEntity[entity],
                    CharacterHitsBuffer = chunkCharacterHitBuffers[i],
                    CharacterDeferredImpulsesBuffer = chunkCharacterDeferredImpulsesBuffers[i],
                    VelocityProjectionHitsBuffer = chunkVelocityProjectionHitBuffers[i],
                    StatefulCharacterHitsBuffer = chunkStatefulCharacterHitsBuffers[i],

                    TutorialCharacter = chunkTutorialCharacters[i],
                    CharacterInputs = chunkTutorialCharacterInputs[i],

                    // Add & set-up any extra data or ComponentDataFromEntitys you might need in your update here
                    CharacterFrictionSurfaceFromEntity = CharacterFrictionSurfaceFromEntity,
                };

                // Update character
                KinematicCharacterUtilities.InitializationUpdate(ref d.CharacterBody, ref d.CharacterHitsBuffer, ref d.VelocityProjectionHitsBuffer, ref d.CharacterDeferredImpulsesBuffer, d.Rotation, out d.CharacterUp);
                KinematicCharacterUtilities.ParentMovementUpdate(ref d.CommonData, ref d.Processor, ref d.Translation, ref d.Rotation, ref d.CharacterBody, ref d.CharacterUp, in d.PhysicsCollider, d.Entity); // safe to remove if not needed
                KinematicCharacterUtilities.GroundingUpdate(ref d.CommonData, ref d.Processor, ref d.Translation, ref d.Rotation, ref d.CharacterBody, ref d.CharacterHitsBuffer, ref d.VelocityProjectionHitsBuffer, in d.PhysicsCollider, d.Entity, d.CharacterUp);

                TutorialCharacterImplementation.BeforeCharacterMove(ref d);

                KinematicCharacterUtilities.MovementAndDecollisionsUpdate(ref d.CommonData, ref d.Processor, ref d.Translation, ref d.CharacterBody, ref d.CharacterHitsBuffer, ref d.VelocityProjectionHitsBuffer, ref d.CharacterDeferredImpulsesBuffer, in d.PhysicsCollider, d.Entity, d.Rotation, out d.CharacterUp);

                TutorialCharacterImplementation.AfterCharacterMove(ref d);

                KinematicCharacterUtilities.ParentMomentumUpdate(ref d.CommonData, ref d.CharacterBody, in d.Translation); // safe to remove if not needed
                KinematicCharacterUtilities.ProcessStatefulCharacterHits(ref d.StatefulCharacterHitsBuffer, in d.CharacterHitsBuffer); // safe to remove if not needed

                // Write back updated data
                // The core character update loop only writes to Translation, Rotation, KinematicCharacterBody, and the various character DynamicBuffers. 
                // You must remember to write back any extra data you modify in your own code
                chunkTranslations[i] = new Translation { Value = d.Translation };
                chunkRotations[i] = new Rotation { Value = d.Rotation };
                CharacterBodyFromEntity[entity] = d.CharacterBody;
                chunkPhysicsColliders[i] = d.PhysicsCollider; // safe to remove if not needed. This would be needed if you resize the character collider, for example
                chunkTutorialCharacters[i] = d.TutorialCharacter; // safe to remove if not needed. This would be needed if you changed data in your own character component
                chunkTutorialCharacterInputs[i] = d.CharacterInputs; // safe to remove if not needed. This would be needed if you changed data in your own character component
            }
        }
    }

    protected override void OnCreate()
    {
        BuildPhysicsWorldSystem = World.GetOrCreateSystem<BuildPhysicsWorld>();
        EndFramePhysicsSystem = World.GetOrCreateSystem<EndFramePhysicsSystem>();

        CharacterQuery = GetEntityQuery(new EntityQueryDesc
        {
            All = MiscUtilities.CombineArrays(
                KinematicCharacterUtilities.GetCoreCharacterComponentTypes(),
                new ComponentType[]
                {
                        typeof(TutorialCharacterComponent),
                        typeof(TutorialCharacterInputs),
                }),
        });

        RequireForUpdate(CharacterQuery);
    }

    protected unsafe override void OnUpdate()
    {
        Dependency = JobHandle.CombineDependencies(EndFramePhysicsSystem.GetOutputDependency(), Dependency);

        Dependency = new TutorialCharacterJob
        {
            DeltaTime = Time.DeltaTime,
            CollisionWorld = BuildPhysicsWorldSystem.PhysicsWorld.CollisionWorld,

            PhysicsVelocityFromEntity = GetComponentDataFromEntity<PhysicsVelocity>(true),
            PhysicsMassFromEntity = GetComponentDataFromEntity<PhysicsMass>(true),
            CharacterBodyFromEntity = GetComponentDataFromEntity<KinematicCharacterBody>(false),
            TrackedTransformFromEntity = GetComponentDataFromEntity<TrackedTransform>(true),

            EntityType = GetEntityTypeHandle(),
            TranslationType = GetComponentTypeHandle<Translation>(false),
            RotationType = GetComponentTypeHandle<Rotation>(false),
            PhysicsColliderType = GetComponentTypeHandle<PhysicsCollider>(false),
            CharacterHitsBufferType = GetBufferTypeHandle<KinematicCharacterHit>(false),
            VelocityProjectionHitsBufferType = GetBufferTypeHandle<KinematicVelocityProjectionHit>(false),
            CharacterDeferredImpulsesBufferType = GetBufferTypeHandle<KinematicCharacterDeferredImpulse>(false),
            StatefulCharacterHitsBufferType = GetBufferTypeHandle<StatefulKinematicCharacterHit>(false),

            TutorialCharacterType = GetComponentTypeHandle<TutorialCharacterComponent>(false),
            TutorialCharacterInputsType = GetComponentTypeHandle<TutorialCharacterInputs>(false),

            CharacterFrictionSurfaceFromEntity = GetComponentDataFromEntity<CharacterFrictionSurface>(true),
        }.ScheduleParallel(CharacterQuery, 1, Dependency);

        Dependency = KinematicCharacterUtilities.ScheduleDeferredImpulsesJob(this, CharacterQuery, Dependency);

        BuildPhysicsWorldSystem.AddInputDependencyToComplete(Dependency);
    }
}
