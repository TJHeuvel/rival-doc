using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;
using Rival;
using Unity.Physics;

public struct TutorialCharacterUpdateData
{
    public TutorialCharacterProcessor Processor;
    public KinematicCharacterCommonData CommonData;

    public Entity Entity;
    public float3 Translation;
    public quaternion Rotation;
    public float3 CharacterUp;
    public PhysicsCollider PhysicsCollider;
    public KinematicCharacterBody CharacterBody;
    public DynamicBuffer<KinematicCharacterHit> CharacterHitsBuffer;
    public DynamicBuffer<KinematicCharacterDeferredImpulse> CharacterDeferredImpulsesBuffer;
    public DynamicBuffer<KinematicVelocityProjectionHit> VelocityProjectionHitsBuffer;
    public DynamicBuffer<StatefulKinematicCharacterHit> StatefulCharacterHitsBuffer;

    public TutorialCharacterComponent TutorialCharacter;
    public TutorialCharacterInputs CharacterInputs;

    public ComponentDataFromEntity<CharacterFrictionSurface> CharacterFrictionSurfaceFromEntity;
}

public static class TutorialCharacterImplementation
{
    public static void BeforeCharacterMove(ref TutorialCharacterUpdateData d)
    {
        if (d.CharacterBody.IsGrounded)
        {
            // Move on ground
            float3 targetVelocity = d.CharacterInputs.WorldMoveVector * d.TutorialCharacter.GroundMaxSpeed;

            // Modify final velocity based on sprinting
            if (d.CharacterInputs.Sprint)
            {
                targetVelocity *= d.TutorialCharacter.SprintSpeedMultiplier;
            }

            // Modify final velocity based on friction surface
            if (d.CharacterFrictionSurfaceFromEntity.HasComponent(d.CharacterBody.GroundHit.Entity))
            {
                targetVelocity *= d.CharacterFrictionSurfaceFromEntity[d.CharacterBody.GroundHit.Entity].VelocityFactor;
            }

            CharacterControlUtilities.StandardGroundMove_Interpolated(ref d.CharacterBody.RelativeVelocity, targetVelocity, d.TutorialCharacter.GroundedMovementSharpness, d.CommonData.DeltaTime, d.CharacterUp, d.CharacterBody.GroundHit.Normal);

            // Jump
            if (d.CharacterInputs.JumpRequested)
            {
                CharacterControlUtilities.StandardJump(ref d.CharacterBody, d.CharacterUp * d.TutorialCharacter.JumpSpeed, true, d.CharacterUp);
            }

            // Push ground dynamic bodies
            KinematicCharacterUtilities.DefaultMethods.UpdateGroundPushing(ref d.CommonData, ref d.CharacterDeferredImpulsesBuffer, ref d.CharacterBody, d.TutorialCharacter.Gravity, 1f);

            // Reset air jumps when grounded
            d.TutorialCharacter._currentAirJumps = 0;
        }
        else
        {
            // Move in air
            float3 airAcceleration = d.CharacterInputs.WorldMoveVector * d.TutorialCharacter.AirAcceleration;
            CharacterControlUtilities.StandardAirMove(ref d.CharacterBody.RelativeVelocity, airAcceleration, d.TutorialCharacter.AirMaxSpeed, d.CharacterUp, d.CommonData.DeltaTime, false);

            // Air Jumps
            if (d.CharacterInputs.JumpRequested && d.TutorialCharacter._currentAirJumps < d.TutorialCharacter.MaxAirJumps)
            {
                CharacterControlUtilities.StandardJump(ref d.CharacterBody, d.CharacterUp * d.TutorialCharacter.JumpSpeed, true, d.CharacterUp);
                d.TutorialCharacter._currentAirJumps++;
            }

            // Gravity
            CharacterControlUtilities.AccelerateVelocity(ref d.CharacterBody.RelativeVelocity, d.TutorialCharacter.Gravity, d.CommonData.DeltaTime);

            // Drag
            CharacterControlUtilities.ApplyDragToVelocity(ref d.CharacterBody.RelativeVelocity, d.CommonData.DeltaTime, d.TutorialCharacter.AirDrag);
        }

        // Rotation (towards move direction)
        if (math.lengthsq(d.CharacterInputs.WorldMoveVector) > 0f)
        {
            CharacterControlUtilities.SlerpRotationTowardsDirectionAroundUp(ref d.Rotation, d.CommonData.DeltaTime, math.normalizesafe(d.CharacterInputs.WorldMoveVector), d.CharacterUp, d.TutorialCharacter.RotationSharpness);
        }

        // Reset jump request
        d.CharacterInputs.JumpRequested = false;
    }

    public static void AfterCharacterMove(ref TutorialCharacterUpdateData d)
    {
        // Detect moving platforms based on grounding 
        // Recommended to do this in "AfterCharacterMove" rather than in "BeforeCharacterMove", because new grounding could potentially be detected during "KinematicCharacterProcessor.MovementAndDecollisionsUpdate"
        // It should also be done before "KinematicCharacterProcessor.ParentMomentumUpdate" since this changes the parent entity
        KinematicCharacterUtilities.DefaultMethods.MovingPlatformDetection(ref d.CommonData, ref d.CharacterBody);
    }
}
