using System.Collections.Generic;
using Unity.Burst;
using Unity.Entities;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Physics;
using Unity.Physics.Extensions;
using Unity.Physics.Systems;
using Unity.Transforms;
using Rival;
using Unity.Collections.LowLevel.Unsafe;

[UpdateInGroup(typeof(KinematicCharacterUpdateGroup))]
public class FirstPersonCharacterMovementSystem : SystemBase
{
    public BuildPhysicsWorld BuildPhysicsWorldSystem;
    public EndFramePhysicsSystem EndFramePhysicsSystem;
    public EntityQuery CharacterQuery;

    [BurstCompile]
    public struct FirstPersonCharacterMovementJob : IJobEntityBatchWithIndex
    {
        public float DeltaTime;
        [ReadOnly]
        public CollisionWorld CollisionWorld;

        [ReadOnly]
        public ComponentDataFromEntity<PhysicsVelocity> PhysicsVelocityFromEntity;
        [ReadOnly]
        public ComponentDataFromEntity<PhysicsMass> PhysicsMassFromEntity;
        [NativeDisableParallelForRestriction] // we need to write to our own characterBody, but we might also need to read from other characterBodies during the update (for dynamics handling)
        public ComponentDataFromEntity<KinematicCharacterBody> CharacterBodyFromEntity;
        [ReadOnly]
        public ComponentDataFromEntity<TrackedTransform> TrackedTransformFromEntity;

        [ReadOnly]
        public EntityTypeHandle EntityType;
        public ComponentTypeHandle<Translation> TranslationType;
        public ComponentTypeHandle<Rotation> RotationType;
        public ComponentTypeHandle<PhysicsCollider> PhysicsColliderType;
        public BufferTypeHandle<KinematicCharacterHit> CharacterHitsBufferType;
        public BufferTypeHandle<KinematicVelocityProjectionHit> VelocityProjectionHitsBufferType;
        public BufferTypeHandle<KinematicCharacterDeferredImpulse> CharacterDeferredImpulsesBufferType;
        public BufferTypeHandle<StatefulKinematicCharacterHit> StatefulCharacterHitsBufferType;

        public ComponentTypeHandle<FirstPersonCharacterComponent> FirstPersonCharacterType;
        public ComponentTypeHandle<FirstPersonCharacterInputs> FirstPersonCharacterInputsType;

        [NativeDisableContainerSafetyRestriction]
        public NativeList<int> TmpRigidbodyIndexesProcessed;
        [NativeDisableContainerSafetyRestriction]
        public NativeList<Unity.Physics.RaycastHit> TmpRaycastHits;
        [NativeDisableContainerSafetyRestriction]
        public NativeList<ColliderCastHit> TmpColliderCastHits;
        [NativeDisableContainerSafetyRestriction]
        public NativeList<DistanceHit> TmpDistanceHits;

        public void Execute(ArchetypeChunk chunk, int batchIndex, int indexOfFirstEntityInQuery)
        {
            NativeArray<Entity> chunkEntities = chunk.GetNativeArray(EntityType);
            NativeArray<Translation> chunkTranslations = chunk.GetNativeArray(TranslationType);
            NativeArray<Rotation> chunkRotations = chunk.GetNativeArray(RotationType);
            NativeArray<PhysicsCollider> chunkPhysicsColliders = chunk.GetNativeArray(PhysicsColliderType);
            BufferAccessor<KinematicCharacterHit> chunkCharacterHitBuffers = chunk.GetBufferAccessor(CharacterHitsBufferType);
            BufferAccessor<KinematicVelocityProjectionHit> chunkVelocityProjectionHitBuffers = chunk.GetBufferAccessor(VelocityProjectionHitsBufferType);
            BufferAccessor<KinematicCharacterDeferredImpulse> chunkCharacterDeferredImpulsesBuffers = chunk.GetBufferAccessor(CharacterDeferredImpulsesBufferType);
            BufferAccessor<StatefulKinematicCharacterHit> chunkStatefulCharacterHitsBuffers = chunk.GetBufferAccessor(StatefulCharacterHitsBufferType);
            NativeArray<FirstPersonCharacterComponent> chunkFirstPersonCharacters = chunk.GetNativeArray(FirstPersonCharacterType);
            NativeArray<FirstPersonCharacterInputs> chunkFirstPersonCharacterInputs = chunk.GetNativeArray(FirstPersonCharacterInputsType);

            // Initialize the Temp collections
            if (!TmpRigidbodyIndexesProcessed.IsCreated)
            {
               TmpRigidbodyIndexesProcessed = new NativeList<int>(24, Allocator.Temp);
            }
            if (!TmpRaycastHits.IsCreated)
            {
                TmpRaycastHits = new NativeList<Unity.Physics.RaycastHit>(24, Allocator.Temp);
            }
            if (!TmpColliderCastHits.IsCreated)
            {
                TmpColliderCastHits = new NativeList<ColliderCastHit>(24, Allocator.Temp);
            }
            if (!TmpDistanceHits.IsCreated)
            {
                TmpDistanceHits = new NativeList<DistanceHit>(24, Allocator.Temp);
            }

            // Assign the global data of the processor
            FirstPersonCharacterProcessor processor = default;
            processor.DeltaTime = DeltaTime;
            processor.CollisionWorld = CollisionWorld;
            processor.CharacterBodyFromEntity = CharacterBodyFromEntity;
            processor.PhysicsMassFromEntity = PhysicsMassFromEntity;
            processor.PhysicsVelocityFromEntity = PhysicsVelocityFromEntity;
            processor.TrackedTransformFromEntity = TrackedTransformFromEntity;
            processor.TmpRigidbodyIndexesProcessed = TmpRigidbodyIndexesProcessed;
            processor.TmpRaycastHits = TmpRaycastHits;
            processor.TmpColliderCastHits = TmpColliderCastHits;
            processor.TmpDistanceHits = TmpDistanceHits;

            // Iterate on individual characters
            for (int i = 0; i < chunk.Count; i++)
            {
                Entity entity = chunkEntities[i];

                // Assign the per-character data of the processor
                processor.Entity = entity;
                processor.Translation = chunkTranslations[i].Value;
                processor.Rotation = chunkRotations[i].Value;
                processor.PhysicsCollider = chunkPhysicsColliders[i];
                processor.CharacterBody = CharacterBodyFromEntity[entity];
                processor.CharacterHitsBuffer = chunkCharacterHitBuffers[i];
                processor.CharacterDeferredImpulsesBuffer = chunkCharacterDeferredImpulsesBuffers[i];
                processor.VelocityProjectionHitsBuffer = chunkVelocityProjectionHitBuffers[i];
                processor.StatefulCharacterHitsBuffer = chunkStatefulCharacterHitsBuffers[i];
                processor.FirstPersonCharacter = chunkFirstPersonCharacters[i];
                processor.FirstPersonCharacterInputs = chunkFirstPersonCharacterInputs[i];

                // Update character
                processor.OnUpdate();

                // Write back updated data
                // The core character update loop only writes to Translation, Rotation, KinematicCharacterBody, and the various character DynamicBuffers. 
                // You must remember to write back any extra data you modify in your own code
                chunkTranslations[i] = new Translation { Value = processor.Translation };
                CharacterBodyFromEntity[entity] = processor.CharacterBody;
                chunkPhysicsColliders[i] = processor.PhysicsCollider; // safe to remove if not needed. This would be needed if you resize the character collider, for example
                chunkFirstPersonCharacters[i] = processor.FirstPersonCharacter; // safe to remove if not needed. This would be needed if you changed data in your own character component
                chunkFirstPersonCharacterInputs[i] = processor.FirstPersonCharacterInputs; // safe to remove if not needed. This would be needed if you changed data in your own character component
            }
        }
    }

    protected override void OnCreate()
    {
        BuildPhysicsWorldSystem = World.GetOrCreateSystem<BuildPhysicsWorld>();
        EndFramePhysicsSystem = World.GetOrCreateSystem<EndFramePhysicsSystem>();

        CharacterQuery = GetEntityQuery(new EntityQueryDesc
        {
            All = MiscUtilities.CombineArrays(
                KinematicCharacterUtilities.GetCoreCharacterComponentTypes(),
                new ComponentType[]
                {
                    typeof(FirstPersonCharacterComponent),
                    typeof(FirstPersonCharacterInputs),
                }),
        });

        RequireForUpdate(CharacterQuery);
    }

    protected unsafe override void OnUpdate()
    {
        Dependency = JobHandle.CombineDependencies(EndFramePhysicsSystem.GetOutputDependency(), Dependency);

        Dependency = new FirstPersonCharacterMovementJob
        {
            DeltaTime = Time.DeltaTime,
            CollisionWorld = BuildPhysicsWorldSystem.PhysicsWorld.CollisionWorld,

            PhysicsVelocityFromEntity = GetComponentDataFromEntity<PhysicsVelocity>(true),
            PhysicsMassFromEntity = GetComponentDataFromEntity<PhysicsMass>(true),
            CharacterBodyFromEntity = GetComponentDataFromEntity<KinematicCharacterBody>(false),
            TrackedTransformFromEntity = GetComponentDataFromEntity<TrackedTransform>(true),

            EntityType = GetEntityTypeHandle(),
            TranslationType = GetComponentTypeHandle<Translation>(false),
            RotationType = GetComponentTypeHandle<Rotation>(false),
            PhysicsColliderType = GetComponentTypeHandle<PhysicsCollider>(false),
            CharacterHitsBufferType = GetBufferTypeHandle<KinematicCharacterHit>(false),
            VelocityProjectionHitsBufferType = GetBufferTypeHandle<KinematicVelocityProjectionHit>(false),
            CharacterDeferredImpulsesBufferType = GetBufferTypeHandle<KinematicCharacterDeferredImpulse>(false),
            StatefulCharacterHitsBufferType = GetBufferTypeHandle<StatefulKinematicCharacterHit>(false),

            FirstPersonCharacterType = GetComponentTypeHandle<FirstPersonCharacterComponent>(false),
            FirstPersonCharacterInputsType = GetComponentTypeHandle<FirstPersonCharacterInputs>(false),
        }.ScheduleParallel(CharacterQuery, 1, Dependency);

        Dependency = KinematicCharacterUtilities.ScheduleDeferredImpulsesJob(this, CharacterQuery, Dependency);

        BuildPhysicsWorldSystem.AddInputDependencyToComplete(Dependency);
    }
}

[UpdateInGroup(typeof(SimulationSystemGroup))]
[UpdateAfter(typeof(FirstPersonPlayerSystem))]
[UpdateAfter(typeof(FixedStepSimulationSystemGroup))]
[UpdateBefore(typeof(TransformSystemGroup))]
public class FirstPersonCharacterRotationSystem : SystemBase
{
    public EntityQuery CharacterQuery;

    protected override void OnCreate()
    {
        CharacterQuery = GetEntityQuery(new EntityQueryDesc
        {
            All = MiscUtilities.CombineArrays(
                KinematicCharacterUtilities.GetCoreCharacterComponentTypes(),
                new ComponentType[]
                {
                    typeof(FirstPersonCharacterComponent),
                    typeof(FirstPersonCharacterInputs),
                }),
        });

        RequireForUpdate(CharacterQuery);
    }

    protected unsafe override void OnUpdate()
    {
        float deltaTime = Time.DeltaTime;
        float fixedDeltaTime = World.GetOrCreateSystem<FixedStepSimulationSystemGroup>().FixedRateManager.Timestep;

        Entities.ForEach((
            Entity entity, 
            ref CharacterInterpolation characterInterpolation, 
            in FirstPersonCharacterInputs characterInputs, 
            in FirstPersonCharacterComponent character, 
            in KinematicCharacterBody characterBody) =>
        {
            Rotation characterRotation = GetComponent<Rotation>(entity);
            float3 characterUp = math.mul(characterRotation.Value, math.up());

            // rotate character root to point at look direction on character up plane
            float3 newCharacterForward = math.normalizesafe(MathUtilities.ProjectOnPlane(characterInputs.LookDirection, characterUp));
            characterRotation.Value = quaternion.LookRotationSafe(newCharacterForward, characterUp);

            // rotate character view to point at look direction relatively to character root rotation
            quaternion worldCharacterViewRotation = quaternion.LookRotationSafe(characterInputs.LookDirection, characterUp);
            quaternion localCharacterViewRotation = math.mul(math.inverse(characterRotation.Value), worldCharacterViewRotation);

            // Add rotation from parent body to the character rotation
            KinematicCharacterUtilities.ApplyParentRotationToTargetRotation(ref characterRotation.Value, in characterBody, fixedDeltaTime, deltaTime);

            // Prevent rotation interpolation
            characterInterpolation.SkipNextRotationInterpolation();

            SetComponent(entity, characterRotation);
            SetComponent(character.CharacterViewEntity, new Rotation { Value = localCharacterViewRotation });
        }).Schedule();
    }
}