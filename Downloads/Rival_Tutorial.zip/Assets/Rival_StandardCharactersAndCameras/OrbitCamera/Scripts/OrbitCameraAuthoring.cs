﻿using System.Collections.Generic;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;

[DisallowMultipleComponent]
public class OrbitCameraAuthoring : MonoBehaviour, IConvertGameObjectToEntity
{
    public GameObject InitialFollowedObject;
    public List<GameObject> IgnoredEntities = new List<GameObject>();
    public OrbitCamera OrbitCamera = OrbitCamera.GetDefault();

    public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
    {
        OrbitCamera.CurrentDistanceFromMovement = OrbitCamera.TargetDistance;
        OrbitCamera.CurrentDistanceFromObstruction = OrbitCamera.TargetDistance;
        OrbitCamera.PlanarForward = -math.forward();
        OrbitCamera.PreviousParentRotation = quaternion.identity;

        if (InitialFollowedObject)
        {
            OrbitCamera.FollowedEntity = conversionSystem.GetPrimaryEntity(InitialFollowedObject);
        }

        dstManager.AddComponentData(entity, OrbitCamera);
        dstManager.AddComponentData(entity, new OrbitCameraInputs());
        DynamicBuffer<OrbitCameraIgnoredEntityBufferElement> ignoredEntitiesBuffer = dstManager.AddBuffer<OrbitCameraIgnoredEntityBufferElement>(entity);

        for (int i = 0; i < IgnoredEntities.Count; i++)
        {
            ignoredEntitiesBuffer.Add(new OrbitCameraIgnoredEntityBufferElement
            {
                Entity = conversionSystem.GetPrimaryEntity(IgnoredEntities[i]),
            });
        }
    }
}