using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Rival;

[UpdateInGroup(typeof(SimulationSystemGroup), OrderFirst = true)]
[UpdateBefore(typeof(FixedStepSimulationSystemGroup))]
public class FirstPersonPlayerSystem : SystemBase
{
    protected override void OnUpdate()
    {
        float deltaTime = Time.DeltaTime;

        // Gather input
        float2 moveInput = float2.zero;
        moveInput.y += Input.GetKey(KeyCode.W) ? 1f : 0f;
        moveInput.y += Input.GetKey(KeyCode.S) ? -1f : 0f;
        moveInput.x += Input.GetKey(KeyCode.D) ? 1f : 0f;
        moveInput.x += Input.GetKey(KeyCode.A) ? -1f : 0f;
        bool jumpInput = Input.GetKeyDown(KeyCode.Space);
        float2 lookInput = new float2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));

        // Iterate on all Player components to apply input to their character
        Entities
            .ForEach((ref FirstPersonPlayer player) =>
            {
                if (HasComponent<FirstPersonCharacterInputs>(player.ControlledCharacter) && HasComponent<FirstPersonCharacterComponent>(player.ControlledCharacter))
                {
                    FirstPersonCharacterInputs characterInputs = GetComponent<FirstPersonCharacterInputs>(player.ControlledCharacter);
                    FirstPersonCharacterComponent character = GetComponent<FirstPersonCharacterComponent>(player.ControlledCharacter);
                    quaternion characterRotation = GetComponent<LocalToWorld>(player.ControlledCharacter).Rotation;
                    quaternion localCharacterViewRotation = GetComponent<Rotation>(character.CharacterViewEntity).Value;

                    // Look
                    ComputeCharacterLook(
                        characterRotation, 
                        localCharacterViewRotation, 
                        lookInput, 
                        player.RotationSpeed,
                        player.MinVAngle,
                        player.MaxVAngle,
                        out quaternion desiredCharacterViewRotation);
                    characterInputs.LookDirection = math.mul(desiredCharacterViewRotation, math.forward());

                    // Move
                    float3 characterForward = math.mul(characterRotation, math.forward());
                    float3 characterRight = math.mul(characterRotation, math.right());
                    characterInputs.MoveVector = (moveInput.y * characterForward) + (moveInput.x * characterRight);
                    characterInputs.MoveVector = Rival.MathUtilities.ClampToMaxLength(characterInputs.MoveVector, 1f);

                    // Jump
                    if (jumpInput)
                    {
                        characterInputs.JumpRequested = jumpInput;
                    }

                    SetComponent(player.ControlledCharacter, characterInputs);
                }
            }).Schedule();
    }

    public static void ComputeCharacterLook(
        quaternion characterRotation, 
        quaternion localCharacterViewRotation, 
        float2 lookInput, 
        float rotationSpeed,
        float minVAngle,
        float maxVAngle,
        out quaternion desiredCharacterViewRotation)
    {
        desiredCharacterViewRotation = characterRotation;
        float3 characterUp = math.mul(characterRotation, math.up());
        quaternion worldCharacterViewRotation = math.mul(characterRotation, localCharacterViewRotation);
        float3 worldCharacterViewForward = math.mul(worldCharacterViewRotation, math.forward());

        // Yaw
        float yawAngleChange = lookInput.x * rotationSpeed;
        quaternion yawRotation = quaternion.Euler(characterUp * math.radians(yawAngleChange));
        desiredCharacterViewRotation = math.mul(desiredCharacterViewRotation, yawRotation);

        // Pitch
        float pitchAnglesDegrees = -(math.degrees(MathUtilities.AngleRadians(characterUp, worldCharacterViewForward)) - 90f);
        pitchAnglesDegrees += lookInput.y * rotationSpeed;
        pitchAnglesDegrees = math.clamp(pitchAnglesDegrees, minVAngle, maxVAngle);
        quaternion pitchRotation = quaternion.Euler(math.right() * -math.radians(pitchAnglesDegrees));
        desiredCharacterViewRotation = math.mul(desiredCharacterViewRotation, pitchRotation);
    }
}
