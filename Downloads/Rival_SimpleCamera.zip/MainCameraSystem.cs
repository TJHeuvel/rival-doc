using System;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;

[UpdateInGroup(typeof(PresentationSystemGroup))]
public class MainCameraSystem : SystemBase
{
    public Transform CameraGameObjectTransform;

    protected override void OnUpdate()
    {
        if (CameraGameObjectTransform && HasSingleton<MainCamera>())
        {
            Entity targetEntity = GetSingletonEntity<MainCamera>();
            MainCamera mainCamera = GetSingleton<MainCamera>();

            LocalToWorld targetLocalToWorld = GetComponent<LocalToWorld>(targetEntity);
            CameraGameObjectTransform.position = targetLocalToWorld.Position;
            CameraGameObjectTransform.rotation = targetLocalToWorld.Rotation;
        }
    }
}