﻿using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;

[DisallowMultipleComponent]
public class OrbitCameraAuthoring : MonoBehaviour, IConvertGameObjectToEntity
{
    public GameObject InitialFollowedObject;
    public OrbitCamera OrbitCamera = OrbitCamera.GetDefault();

    public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
    {
#if UNITY_EDITOR
        dstManager.SetName(entity, "OrbitCamera");
#endif

        OrbitCamera.CurrentDistanceFromMovement = OrbitCamera.TargetDistance;
        OrbitCamera.CurrentDistanceFromObstruction = OrbitCamera.TargetDistance;
        OrbitCamera.PlanarForward = -math.forward();
        OrbitCamera.PreviousParentRotation = quaternion.identity;

        OrbitCamera.FollowedEntity = conversionSystem.GetPrimaryEntity(InitialFollowedObject);

        dstManager.AddComponentData(entity, OrbitCamera);
        dstManager.AddComponentData(entity, new OrbitCameraInputs());
        dstManager.AddBuffer<IgnoredEntityBufferElement>(entity);
    }
}